# LKSWNSB CTF — Header Juggling Challenge

A web-based CTF challenge where the flag is hidden inside an **HTTP response header**.

---

## 📂 Project Structure

```
ctf-header-challenge/
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── app.py                  ← Flask app (injects flag into X-Flag header)
├── templates/
│   ├── base.html           ← Shared layout (dark hacker theme)
│   ├── index.html          ← Home / challenge page
│   ├── about.html          ← Backstory & rules
│   └── hint.html           ← Progressive hints
└── README.md
```

---

## 🚀 How to Run

### Option A — Docker Compose (Recommended)

```bash
cd ctf-header-challenge
docker compose up -d --build
```

Then open: **http://localhost:5000**

### Option B — Docker Only

```bash
docker build -t lkswnsb-ctf .
docker run -d -p 5000:5000 --name lkswnsb-ctf lkswnsb-ctf
```

### Option C — Run Locally (No Docker)

```bash
pip install -r requirements.txt
python app.py
```

---

## 🔍 How the Challenge Works

1. The Flask app injects a **custom HTTP response header** called `X-Flag` on every route.
2. The flag is **never rendered** on the HTML page — it only exists in the response metadata.
3. Players must use browser DevTools, `curl`, or a script to inspect the headers.

### Where the flag is injected (`app.py`):

```python
response.headers["X-Flag"] = FLAG
```

---

## ✅ Solution (Spoiler)

### Method 1 — Browser DevTools
1. Open the site in Chrome/Firefox.
2. Press **F12** → go to the **Network** tab.
3. Reload the page.
4. Click on the main document request.
5. Under **Response Headers**, find `X-Flag`.

### Method 2 — curl

```bash
curl -v http://localhost:5000/
# Look for: < X-Flag: LKSWNSB{...}
```

### Method 3 — Python

```python
import requests
r = requests.get("http://localhost:5000/")
print(r.headers.get("X-Flag"))
```

---

## 🏁 Flag

```
LKSWNSB{h3ad3r_jug4_p3nt1ng}
```

---

## ⚙️ Customization

| What | Where | How |
|------|-------|-----|
| Change the flag | `app.py` → `FLAG` variable | Edit the string |
| Change the port | `docker-compose.yml` → `ports` | e.g., `"8080:5000"` |
| Add new routes | `app.py` + `templates/` | Add a new route + template |
| Add more hints | `templates/hint.html` | Add another hint block |

---

> **Tip for CTF organizers:** To make it harder, remove the `/hint` page and the instructional text from `index.html`. Let players figure out the attack surface on their own.
